## 测试
* TestStringFormat.java(测试字符串格式化输出，不同占位符使用)
* Serialize,jdk序列化、json序列化
* `JwebUnitTest`测试
> 先建立user library，将jwebunit的jar都依赖进来，再在工程的buildpath上依赖，![JwebUnitTest](../../../src/main/webapp/image/jwebunitdemo.png)
* `MockTest`-mockito类库测试
